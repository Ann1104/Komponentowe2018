﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bazaPart2
{
    partial class Ksiazka
    {
        public override string ToString()
        {

            string autorzy = "";
            foreach(Autor a in Autors)
            {
                autorzy += a.Imie + ", ";
            }
            //usuniecie ostatniego przecinka - dopisac

            return string.Format("{0} ({1})", Tytul, autorzy);
        }
    }

    partial class Autor
    {
        /*public override string ToString()
        {
            return string.Format(" {0} {1}", Ksiazka, Imie);
        }*/
    }
}
