﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bazaPart2
{
    public partial class UserControlAutor : UserControl
    {
        private Autor a;

        public UserControlAutor()
        {
            InitializeComponent();
        }

        public UserControlAutor(Autor a)
        {
            InitializeComponent();
            this.a = a;
            textBox1.Text = a.Imie;
            dateTimePicker1.Value = a.DataUrodzenia;
        }

        public void przygotujZapisz(Ksiazka k)
        {
            if (a == null)
            {
                a = new Autor();
                a.Ksiazka = k;
                Form1.bazaDC.Autors.InsertOnSubmit(a);
            }
            a.Imie = textBox1.Text;
            a.DataUrodzenia = dateTimePicker1.Value;
        }

        private void buttonUsun_Click(object sender, EventArgs e)
        {
            this.Visible = false;
           // UserControlAutor uca = sender as UserControlAutor;
        }

        public void usunAutora()
        {
            Form1.bazaDC.Autors.DeleteOnSubmit(a);
        }
    }
}
