﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GraMario
{
    public partial class FormGry : Form
    {
        Gra mojaGra;
       
        public FormGry()
        {
            InitializeComponent();
            mojaGra = new Gra();
            mojaGra.Tick += Odrysuj;
            Odrysuj();
        }

        private void Odrysuj()
        {
            Graphics g;
            pictureBoxPlansza.Image = new Bitmap(pictureBoxPlansza.Width, pictureBoxPlansza.Height);
            g = Graphics.FromImage(pictureBoxPlansza.Image);
            RectangleF m = przeliczRect(mojaGra.Mario);  
            g.FillEllipse(new SolidBrush(Color.Red), m);

            foreach(RectangleF p in mojaGra.Platformy)
            {
                przeliczRect(p);
                
            }
            pictureBoxPlansza.Refresh();

        }

        private RectangleF przeliczRect(RectangleF r)
        {
            return new RectangleF(PrzeliczX(r.X), PrzeliczY(r.Y), PrzeliczX(r.Width), PrzeliczY(r.Height));
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                mojaGra.Podskocz();
            }

        }

        private float PrzeliczX(float x)
        {
            return x * pictureBoxPlansza.Width / 100;
        }

        private float PrzeliczY(float y)
        {
            return y * pictureBoxPlansza.Height / 100;
        }
    }
}
