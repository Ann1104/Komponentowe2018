﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GraMario
{
    class Gra
    {
        public delegate void metodaGra();
        public event metodaGra Tick;
        private PointF marioPolozenie; //przecinkowy
        private SizeF marioRozmiar;
        private Timer timer;
        private int czasSkoku = 0;
        private List<RectangleF> platformy;

        public List<RectangleF> Platformy
        {
            get
            {
                return platformy;
            }
        }

        public RectangleF Mario
        {
            get
            {
                return new RectangleF(marioPolozenie, marioRozmiar);
            }
        }
        public Gra()
        {
            marioPolozenie = new PointF(10, 80);
            marioRozmiar = new Size(5, 10);
            platformy = new List<RectangleF>();

            platformy.Add(new RectangleF(0,90,50,10));
            platformy.Add(new RectangleF(0, 70, 50, 10));
            platformy.Add(new RectangleF(0, 90, 50, 10));

            timer = new Timer();
            timer.Interval = 100;
            timer.Start();
            timer.Tick += Timer_Tick;
            czasSkoku = 1;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            for(int i=0; i< platformy.Count; i++)
            {
                platformy[i] = new RectangleF( new PointF(platformy[i].X - 1, platformy[i].Y),
                                                platformy[i].Size);
            }

            if (czasSkoku > 0)
            {
                marioPolozenie.Y-=2;
                czasSkoku--;
            }
            //spadanie
            else if(!czyNaPlatformie())
                {
                    marioPolozenie.Y++;
                }
                
            
            marioPolozenie.X++;
            if (this.Tick != null)
            {
                this.Tick();
            }
           
            if (marioPolozenie.Y + marioRozmiar.Width > 100)
            {
                timer.Stop();
                MessageBox.Show("KONIEC GRY");
            }
        }

        private bool czyNaPlatformie()
        {
           foreach (RectangleF p in platformy)
            {
                if (marioPolozenie.Y + marioRozmiar.Width == p.Y && marioPolozenie.X >= p.X && marioRozmiar.Width <= p.X + p.Width)
                //marioPolozenie.X + marioRozmiar.Width <= p.X + p.Width
                {
                    return true;
                }
            }
            return false;
        }

        public void Podskocz()
        {
            if (czyNaPlatformie())
            {
                czasSkoku = 15;
            }
            
            
        }
    }
}
