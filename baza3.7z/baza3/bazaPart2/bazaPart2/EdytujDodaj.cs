﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bazaPart2
{
    public partial class EdytujDodaj : Form
    {
        public EdytujDodaj()
        {
            InitializeComponent();
            UserControlAutor uca = new UserControlAutor();
            flowLayoutPanelAutorzy.Controls.Add(uca);
        }
        private Ksiazka kk;

        public EdytujDodaj(Ksiazka k)
        {
            InitializeComponent();
            this.kk = k;
            textBox1.Text = kk.Tytul;
            numericUpDown1.Value = kk.IloscStron;
            dateTimePicker1.Value = kk.DataWydania;
            foreach (Autor a in kk.Autors)
            {
                UserControlAutor uca = new UserControlAutor(a);
                flowLayoutPanelAutorzy.Controls.Add(uca);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(kk != null)
            {
                kk.Tytul = textBox1.Text;
                kk.IloscStron = (int)numericUpDown1.Value;
                kk.DataWydania = dateTimePicker1.Value;
                //foreach po autorach jak nowy to zapisac jak nie to update
            }
            else
            {
                Ksiazka nowa = new Ksiazka();
                nowa.Tytul = textBox1.Text;
                nowa.IloscStron = (int)numericUpDown1.Value;
                nowa.DataWydania = dateTimePicker1.Value;
                Form1.bazaDC.Ksiazkas.InsertOnSubmit(nowa);
            }
           
            Form1.bazaDC.SubmitChanges();
            Close();
        }

        private void buttonAddAutor_Click(object sender, EventArgs e)
        {
            UserControlAutor uca = new UserControlAutor();
            flowLayoutPanelAutorzy.Controls.Add(uca);
        }
    }
}
