﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bazaPart2
{
    public partial class Form1 : Form
    {
        static public bazaDataContext bazaDC = new bazaDataContext();
        public Form1()
        {
            InitializeComponent();
          
            // Ksiazka k = new Ksiazka();
            listaKsiazek.Items.AddRange(bazaDC.Ksiazkas.ToArray());
            /* foreach (Ksiazka k in BazaDC.Ksiazkas)
            {
            listaKsiazek.Items.Add(k);
            {
            */
        }

        private void buttonDodaj_Click(object sender, EventArgs e)
        {
            EdytujDodaj oknoEdycji = new EdytujDodaj();
            oknoEdycji.ShowDialog();
            listaKsiazek.Items.Clear();
            listaKsiazek.Items.AddRange(bazaDC.Ksiazkas.ToArray());

        }
        
        private void buttonEdytuj_Click(object sender, EventArgs e)
        {
            if (listaKsiazek.SelectedItem != null)
            {
                Ksiazka k = listaKsiazek.SelectedItem as Ksiazka;
                EdytujDodaj oknoEdycji = new EdytujDodaj(k);
                oknoEdycji.ShowDialog();
                listaKsiazek.Items.Clear();
                listaKsiazek.Items.AddRange(bazaDC.Ksiazkas.ToArray());
            }
            
        }

        private void buttonUsun_Click(object sender, EventArgs e)
        {
            bazaDC.Ksiazkas.DeleteOnSubmit(listaKsiazek.SelectedItem as Ksiazka);
            bazaDC.SubmitChanges();
            listaKsiazek.Items.Clear();
            listaKsiazek.Items.AddRange(bazaDC.Ksiazkas.ToArray());
        }

    }
}
