﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bazaPart2
{
    public partial class UserControlAutor : UserControl
    {
        private Autor a;

        public UserControlAutor()
        {
            InitializeComponent();
        }

        public UserControlAutor(Autor a)
        {
            InitializeComponent();
            this.a = a;
            textBox1.Text = a.Imie;
            dateTimePicker1.Value = a.DataUrodzenia;
        }

        private void buttonDodaj_Click(object sender, EventArgs e) //zle
        {
            a = new Autor();
            a.Imie = textBox1.Text;
            a.DataUrodzenia = dateTimePicker1.Value;
            //Ksiazka k = sender as Ksiazka;
            //a.idKsiazki = k.Id;
        }
    }
}
