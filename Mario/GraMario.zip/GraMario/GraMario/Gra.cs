﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GraMario
{
    class Gra
    {
        private RectangleF mario;
        private DateTime czasSkokuDo;
        private List<RectangleF> platformy;
        private List<RectangleF> monety;
        private Timer czas;
        private Int32 punkty;

        public delegate void metodaSenderGra(Gra sender);
        public event metodaSenderGra Zmiana;
        public RectangleF Mario
        {
            get
            {
                return mario;
            }
        }
        public List<RectangleF> Platformy
        {
            get
            {
                return platformy;
            }
        }

        public List<RectangleF> Monety
        {
            get
            {
                return monety;
            }
        }

        public int Punkty
        {
            get
            {
                return punkty;
            }
        }

        public Gra()
        {
            mario = new RectangleF(10, 10, 5, 10);
           
            platformy = new List<RectangleF>();
            monety = new List<RectangleF>();

            generujPlansze();

            czasSkokuDo = DateTime.Now;

            czas = new Timer();
            czas.Interval = 20;
            czas.Start();
            czas.Tick += Czas_Tick;
        }

        private void generujPlansze()
        {
            Random gen = new Random();
            float start = 0;
            float szerokosc = 0;
            float y;
            for (int i=0; i<100; i++)
            {
                szerokosc = gen.Next(20, 50);
                y = gen.Next(50, 90);
                platformy.Add(new RectangleF(start, y ,szerokosc,10));

                start += szerokosc + gen.Next(5, 15);

                monety.Add(new RectangleF(start + gen.Next(0, (int)szerokosc+4), y - 30, 4, 4));
            }
        }

        private void Czas_Tick(object sender, EventArgs e)
        {
            //ruch elementow
            przesunElementy(platformy);
            przesunElementy(monety);

            //skacze
            if (DateTime.Now < czasSkokuDo)
            {
                mario.Y -= 1;
            }
            else
            {
                //spada
                if (!CzyNaPlatformie())
                {
                    mario.Y += 1;
                }
            }

            for (int i = 0; i < monety.Count; i++)
            {
                //badamy kolizję mario monety[1]
                if (!RectangleF.Intersect(mario, monety[i]).IsEmpty)
                {
                    monety.RemoveAt(i);
                    punkty++;
                    break;
                }
            }

            if (Zmiana != null)
            {
                Zmiana(this);
            }

            if (mario.Y + mario.Width * 2 > 100)
            {
                czas.Stop();
                MessageBox.Show("KONIEC GRY");
            }
        }

        private void przesunElementy(List<RectangleF> elementy)
        {
            for (int i = 0; i < elementy.Count; i++)
            {
                elementy[i] = new RectangleF(
                                              elementy[i].X - 0.3f,
                                              elementy[i].Y,
                                              elementy[i].Width,
                                              elementy[i].Height
                                             );
            }
        }

        internal void Podskocz()
        {
            if (CzyNaPlatformie())
            {
                czasSkokuDo = DateTime.Now + TimeSpan.FromSeconds(1); //przez sekundę się unosi i spada
            }
        }

        private bool CzyNaPlatformie()
        {
            foreach (RectangleF p in platformy)
            {
                if (mario.Y + mario.Height >= p.Y &&
                   mario.Y + mario.Height <= p.Y + p.Height &&
                   mario.X >= p.X &&
                   mario.X <= p.X + p.Width)
                {
                    mario.Y = p.Y - mario.Height;
                    return true;
                }
            }
            return false;
        }

    }
}
