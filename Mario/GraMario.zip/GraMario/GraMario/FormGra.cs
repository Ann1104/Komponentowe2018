﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GraMario
{
    public partial class FormGra : Form
    {
        Graphics g;
        Gra mojaGra;
        public FormGra()
        {
            InitializeComponent();
            mojaGra = new Gra();
            mojaGra.Zmiana += Odrysuj;
            //mojaGra.KoniecGry += Koniec 
            // metodakoniec messagebox, mojagra zmiana, odrysuj
        }

        private void Odrysuj(Gra sender)
        {
            pictureBoxWizualizacja.Image = new Bitmap(pictureBoxWizualizacja.Width, pictureBoxWizualizacja.Height);
            g = Graphics.FromImage(pictureBoxWizualizacja.Image);

            foreach (RectangleF p in mojaGra.Platformy)
            {
                g.FillRectangle(new SolidBrush(Color.Green), Przeskaluj(p));
            }
            foreach (RectangleF m in mojaGra.Monety)
            {
                g.FillEllipse(new SolidBrush(Color.Yellow), Przeskaluj(m));
            }
            g.FillEllipse(new SolidBrush(Color.Red), Przeskaluj(mojaGra.Mario));
            //g.DrawImage(image*spawdzic w setings, polozenie mario)
            g.DrawString(mojaGra.Punkty.ToString(),
                new System.Drawing.Font("Arial Rounded MT Bold", 36F),
                new SolidBrush(Color.Black),
                10, 10);
        }

        private RectangleF Przeskaluj(RectangleF r)
        {
            return new RectangleF(
                                    r.X /100 * pictureBoxWizualizacja.Width,
                                    r.Y / 100 * pictureBoxWizualizacja.Height,
                                    r.Width / 100 * pictureBoxWizualizacja.Width,
                                    r.Height/ 100 * pictureBoxWizualizacja.Height
                                 );
        }

        private void FormGra_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode==Keys.Space)
            { 
                mojaGra.Podskocz();
            }
        }
    }
}
