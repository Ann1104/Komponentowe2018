﻿namespace GraMario
{
    partial class FormGra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBoxWizualizacja = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWizualizacja)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBoxWizualizacja
            // 
            this.pictureBoxWizualizacja.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxWizualizacja.Location = new System.Drawing.Point(0, 0);
            this.pictureBoxWizualizacja.Name = "pictureBoxWizualizacja";
            this.pictureBoxWizualizacja.Size = new System.Drawing.Size(592, 276);
            this.pictureBoxWizualizacja.TabIndex = 0;
            this.pictureBoxWizualizacja.TabStop = false;
            // 
            // FormGra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(592, 276);
            this.Controls.Add(this.pictureBoxWizualizacja);
            this.Name = "FormGra";
            this.Text = "Mario :-)";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FormGra_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWizualizacja)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBoxWizualizacja;
    }
}

