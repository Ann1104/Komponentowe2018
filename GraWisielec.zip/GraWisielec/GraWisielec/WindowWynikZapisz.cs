﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GraWisielec
{
    public partial class WindowWynikZapisz : Form
    {
        bazaWisielecDataContext BazaDC = new bazaWisielecDataContext();
        private Haslo hasloBaza;
        private int strzały;

        public WindowWynikZapisz(Haslo hasloBaza, int strzały)
        {
            InitializeComponent();
            this.hasloBaza = hasloBaza;
            this.strzały = strzały;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Wynik nowy = new Wynik();

            if(textBoxPseudonim.Text != null)
            {
                nowy.Pseudonim = textBoxPseudonim.Text;
                nowy.Strzaly = strzały;
                hasloBaza.Wyniks.Add(nowy);
                Close();
                FormWyniki fw = new FormWyniki(hasloBaza);
                fw.ShowDialog();

            }
        }

        private void textBoxPseudonim_TextChanged(object sender, EventArgs e)
        {
            textBoxPseudonim.BackColor = Color.White;
        }
    }
}
