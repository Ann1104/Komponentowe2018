﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GraWisielec
{
    public partial class FormWyniki : Form
    {
        bazaWisielecDataContext BazaDC = new bazaWisielecDataContext();
        private Haslo hasloBaza;

        public FormWyniki(Haslo hasloBaza)
        {
            InitializeComponent();
            this.hasloBaza = hasloBaza;

            foreach( Wynik w in BazaDC.Wyniks )
            {
                if (w.Haslo == hasloBaza)
                {
                    Label l = new Label();
                    l.Text = w.ToString();
                    flowLayoutPanel1.Controls.Add(l);
                }
            }
        }
    }
    public partial class Wynik
    {
        public override string ToString()
        {
            return "aa";
        }
    }
}
