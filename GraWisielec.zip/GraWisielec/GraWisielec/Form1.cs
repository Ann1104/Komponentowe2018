﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GraWisielec
{
    public partial class Form1 : Form
    {
        bazaWisielecDataContext BazaDC = new bazaWisielecDataContext();
        Haslo hasloBaza;
        char[] hasloZakryte;
        Random gen = new Random();
        int strzaly = 0;

        public Form1()
        {
            InitializeComponent();
            Start();
        }

        private void Start()
        {
            hasloBaza = BazaDC.Haslos.Skip(gen.Next(BazaDC.Haslos.Count())).First();
            hasloZakryte = hasloBaza.Slowo.ToCharArray();
            strzaly = 0;
            for (int i=1; i<hasloZakryte.Length-1; i++)
            {
                hasloZakryte[i] = '_';
            }

            labelHaslo.Text = new string(hasloZakryte);
            
        }

        private void buttonOdkryj_Click(object sender, EventArgs e)
        {
            char[] hasloDoOdkrycia = hasloBaza.Slowo.ToCharArray();
            strzaly++;
            try
            {
                char litera = Convert.ToChar(textBoxLitera.Text.ToUpper());

                for(int i=1; i< hasloDoOdkrycia.Length-1; i++)
                {
                    if(hasloDoOdkrycia[i] ==litera)
                    {
                        hasloZakryte[i] = litera;
                    }
                }
                labelHaslo.Text = new string(hasloZakryte);
                CzyKoniec();
            }
            catch(Exception)
            {
                textBoxLitera.BackColor = Color.Red;
            }
        }

        private void CzyKoniec()
        {
            int licznik = 0;

            for (int i = 1; i < hasloZakryte.Length - 1; i++)
            {
                if (hasloZakryte[i] == '_')
                    licznik++;
            }

            if (licznik==0)
            {
               WindowWynikZapisz wwz = new  WindowWynikZapisz(hasloBaza, strzaly);
                wwz.ShowDialog();
                Start(); BazaDC.SubmitChanges();
            }
        }

        private void textBoxLitera_TextChanged(object sender, EventArgs e)
        {
            textBoxLitera.BackColor = Color.White;
        }
    }
}
