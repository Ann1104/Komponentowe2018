﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zegar
{
    public partial class UserControlZegar : UserControl
    {
        private Boolean czyCyfrowy = true;
        public Boolean CzyCyfrowy
        {
            get { return czyCyfrowy; }
            set
            {
                czyCyfrowy = value;
                if (czyCyfrowy)
                {
                    label1.Visible = true;
                    pictureBox1.Visible = false;
                }
                else
                {
                    label1.Visible = false;
                    pictureBox1.Visible = true;
                }

            }

        }
        public UserControlZegar()
        {
            InitializeComponent();
            timer1_Tick(null, null);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            if (czyCyfrowy)
            {
                label1.Text = DateTime.Now.ToLongTimeString();
            }
            else
            {
                pictureBox1.Image = new Bitmap(pictureBox1.Width, pictureBox1.Height);
                Graphics g = Graphics.FromImage(pictureBox1.Image);

                Int32 r = Math.Min(pictureBox1.Width / 2, pictureBox1.Height / 2) - 2;
                Point S = new Point(pictureBox1.Width/2, pictureBox1.Height/2);

                g.Clear(BackColor);
                g.DrawEllipse(new Pen(ForeColor, 3), S.X - r, S.Y -r, r*2, r*2);

               // g.DrawLine(new Pen(ForeColor, 2), S.X, S.Y, S.X, S.Y+r);

                int sekundy = DateTime.Now.Second;
                double katSekundy = (2 * Math.PI *6 / 360) * (sekundy-15);
                double xSek = r * Math.Cos(katSekundy);
                double ySek = r * Math.Sin(katSekundy);

                g.DrawLine(new Pen(Color.Red, 1), S.X, S.Y, S.X + (int)xSek, S.Y + (int)ySek);

                int minuty = DateTime.Now.Minute;
                double katMinuty = (2 * Math.PI * 6 / 360) * (minuty - 15);
                double xMin = r * Math.Cos(katMinuty);
                double yMin = r * Math.Sin(katMinuty);

                g.DrawLine(new Pen(Color.Black, 2), S.X, S.Y, S.X + (int)xMin, S.Y + (int)yMin);

                //zmienić żeby godzina nie była co godzinę tylko o ułamki godziny 
                int godziny = DateTime.Now.Hour;
                double katGodziny = (2 * Math.PI * 6 / 360) * (godziny - 15);
                double xGodz = r * Math.Cos(katGodziny);
                double yGodz = r * Math.Sin(katGodziny);

                g.DrawLine(new Pen(Color.Brown, 3), S.X, S.Y, S.X + (int)xGodz , S.Y + (int)yGodz);
            }
        }
    }
}
