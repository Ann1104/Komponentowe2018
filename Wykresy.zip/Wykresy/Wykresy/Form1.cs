﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Wykresy
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            chart1.Series.Clear();
        }

        private void buttonRysuj_Click(object sender, EventArgs e)
        {
            chart1.Series.Clear();
            chart1.BackColor = Color.White;
            foreach (UserControlFunkcja ucf in flowLayoutPanel1.Controls)
            {
                Series s = ucf.dajSerie();
                if(s!=null)
                {
                    chart1.BackColor = Color.Silver;
                    chart1.Series.Add(s);
                }
            }
        }

        private void buttonDodaj_Click(object sender, EventArgs e)
        {
            UserControlFunkcja ucf = new UserControlFunkcja();
            flowLayoutPanel1.Controls.Add(ucf);
            ucf.doUsunieciaEvent += Ucf_doUsunieciaEvent;

        }

        private void Ucf_doUsunieciaEvent(UserControlFunkcja a)
        {
            flowLayoutPanel1.Controls.Remove(a);
            buttonRysuj_Click(null, null);
        }

    }
}
