﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Wykresy
{
    public partial class UserControlFunkcja : UserControl
    {
        public double A
        {
            get { return Convert.ToDouble(textBoxA.Text); }
        }
        public double B
        {
            get { return Convert.ToDouble(textBoxB.Text); }
        }
        public double C
        {
            get { return Convert.ToDouble(textBoxC.Text); }
        }

        public UserControlFunkcja()
        {
            InitializeComponent();
            textBoxA.Text = "1";
            textBoxB.Text = "1";
            textBoxC.Text = "1";
        }

        public delegate void doUsunieciaDelegate(UserControlFunkcja a) ; //delegate = wskaznik do funkcji, deklaracja funkcji do usuniecia kontrolki
        public event doUsunieciaDelegate doUsunieciaEvent; //event typu delegate

        private void buttonUsun_Click(object sender, EventArgs e)
        {
            //this.Visible = false;
            if(doUsunieciaEvent!=null)
            { 
                doUsunieciaEvent(this);
            }
        }

        public Series dajSerie()
        {
            Series s = null;
            try
            {
                //if (this.Visible == true)
                //{
                    s = new Series();
                    s.ChartType = SeriesChartType.Line;

                    double a = A;
                    double b = B;
                    double c = C;

                    for (double x = -10; x <= 10; x += 0.1)
                    {
                        double y = a * x * x + b * x + c;
                        s.Points.Add(new DataPoint(x, y));
                    }
               // }
            }
            catch
            {
                return null;
            }

            return s;
        }

        private void textBoxA_TextChanged(object sender, EventArgs e)
        {
            double a;
            if( double.TryParse(textBoxA.Text, out a))
            {

            }
        }
    }
}
